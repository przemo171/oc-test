-- Enable pgcrypto for gen_random_uuid used in some converted constructs
CREATE EXTENSION IF NOT EXISTS pgcrypto;
