# frozen_string_literal: true

module Exceptions
  class MethodNotAllowed < RuntimeError
  end
end
