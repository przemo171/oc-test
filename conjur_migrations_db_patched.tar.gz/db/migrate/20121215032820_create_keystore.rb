# frozen_string_literal: true

require 'slosilo/adapters/sequel_adapter/migration'
