# frozen_string_literal: true

module Exceptions
  class Forbidden < RuntimeError
  end
end
