# Artifactory OpenShift (non-admin) manifests

Files in this package are intended to be applied in order:

1. oc apply -f 00-namespace.yaml
2. oc apply -f 01-postgres-secret.yaml
3. oc apply -f 02-postgres-pvc.yaml
4. oc apply -f 03-postgres-deployment.yaml
5. oc apply -f 04-postgres-service.yaml
6. oc apply -f 05-artifactory-pvc.yaml
7. oc apply -f 06-artifactory-deployment.yaml
8. oc apply -f 07-artifactory-service.yaml

Notes:
- This package intentionally does NOT include an OpenShift Route (per request).
- Images:
  - PostgreSQL: postgres:latest
  - Artifactory OSS: releases-docker.jfrog.io/jfrog/artifactory-oss:latest
- If your cluster cannot pull from releases-docker.jfrog.io, replace the image with a mirror or a specific tag.
- If your StorageClass requires special access (NFS with root squash), contact cluster admin to provision compatible PV.
- To change DB credentials, edit 01-postgres-secret.yaml before applying.
